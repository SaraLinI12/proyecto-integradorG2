package pe.edu.upeu.modelo;


import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ClienteTO {  
  public String dniruc,	nombreRS, tipo;
}

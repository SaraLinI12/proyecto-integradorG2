package pe.edu.upeu.app;

import pe.edu.upeu.gui.MainGUI;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        new MenuOpciones().login();
        // new MainGUI();
    }
}

package pe.edu.upeu.modelo;

import lombok.Data;

@Data
public class UsuarioTO {
    public String usuario, clave;

}

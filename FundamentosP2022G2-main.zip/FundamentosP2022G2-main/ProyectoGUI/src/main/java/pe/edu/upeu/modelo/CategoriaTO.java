package pe.edu.upeu.modelo;

import lombok.Data;

@Data
public class CategoriaTO {    
    public String idCate, nombre;
}

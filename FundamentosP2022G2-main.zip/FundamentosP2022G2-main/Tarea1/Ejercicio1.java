public class Ejercicio1{

  public static void main(String[] arg){
    System.out.println("Hola Como estas?");
  }
  
}